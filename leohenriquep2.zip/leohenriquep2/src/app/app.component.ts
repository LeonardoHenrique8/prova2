import { Component } from '@angular/core';
import { Conta } from './conta';
import { ContaService } from './conta.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  newConta: Conta = {} as Conta

  constructor(private contaService: ContaService) {}

  ngOnInit() {
  }

  save(myForm: any) {
    this.contaService.post(this.newConta).subscribe(
      () => {
        myForm.reset()
        this.newConta = {} as Conta
      }
    )
  }

  loadData() {
    this.contaService.get().subscribe(
      
    )
  }

  deleteFatura(faturaId: number) {
    this.contaService.delete(faturaId).subscribe(
      () => this.loadData()
    )
  }

  
}

