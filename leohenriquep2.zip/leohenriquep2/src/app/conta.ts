export interface Conta {
    amount: Number
    product: String
    payment: String
    customer: String
  }