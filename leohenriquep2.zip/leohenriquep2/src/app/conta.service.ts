import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Conta } from './conta';

@Injectable({
  providedIn: 'root'
})
export class ContaService {

    private url = "https://calm-anchorage-20290.herokuapp.com/api/v1/bills"

    constructor(private http: HttpClient) { }
  
    post(fatura: Conta) : Observable<Conta> {
      console.log(fatura)
      return this.http.post<Conta>(this.url, fatura)
    } 
    get() : Observable<Conta[]> {
        return this.http.get<Conta[]>(this.url + '?customer')
      }
    
  
    getById(nome) : Observable<Conta[]> {
      return this.http.get<Conta[]>(this.url + '?customer=' + nome)
    }
  
    delete(contax: number) : Observable<Conta> {
      return this.http.delete<Conta>(this.url + "/" + contax)
    }
  
  
}

